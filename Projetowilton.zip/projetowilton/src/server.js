import app from './app'; //const app = require('./app');

app.listen(3000);